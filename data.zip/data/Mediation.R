
suppressPackageStartupMessages({
  library(haven)
  library(dplyr)
  library(tidyr)
  library(causalweight)
  library(sandwich)
  library(lmtest)
  library(EValue)
})
set.seed(42)

out_dir <- "C:/Users/10458/Desktop/data/Mediation"
if (!dir.exists(out_dir)) dir.create(out_dir, showWarnings = FALSE)

trim_main   <- 1e-8
delta_sens  <- 1
seed_main   <- 42    
n_fold_reps <- as.integer(Sys.getenv("N_FOLD_REPS", "20"))
if (is.na(n_fold_reps) || n_fold_reps < 1) n_fold_reps <- 20

data_path <- "C:/Users/10458/Desktop/data/main_data.dta"


individual <- read_dta(data_path) %>%

  mutate(Broad_band_China2 = ifelse(is.na(Broad_band_China2) & year == 2011,
                                    0, Broad_band_China2))

required_vars <- c("ID", "year", "city_code", "health_pca",
                   "Broad_band_China1", "Broad_band_China2", "freq_social10",
                   "age", "marry", "drinkl", "smoken", "gender", "rural",
                   "edu", "log_per_gdp", "per_bed", "per_doc")
missing_vars <- setdiff(required_vars, names(individual))
if (length(missing_vars) > 0) {
  stop("The following required variables are missing: ",
       paste(missing_vars, collapse = ", "))
}

cat("Data:", nrow(individual), "person-year observations,",
    n_distinct(individual$ID), "individuals,",
    n_distinct(individual$city_code), "cities,",
    n_distinct(individual$year), "waves.\n")


individual <- individual %>%
  mutate(row_id = row_number())

individual <- individual %>%
  arrange(ID, year) %>%
  group_by(ID) %>%
  mutate(
    m_med = 5 - freq_social10
  ) %>%
  ungroup() %>%
  arrange(row_id)


lag_check <- individual %>%
  group_by(ID) %>%
  summarise(n = n(), .groups = "drop")
if (any(lag_check$n != 4)) {
  warning("The panel is not balanced (not every ID has 4 waves). ",
          "Lag variables are still constructed within ID-year.")
}
stopifnot(all(is.finite(individual$m_med[!is.na(individual$m_med)])))

cat("\nMediator distribution:\n")
print(summary(individual$m_med))
if (length(unique(individual$m_med[!is.na(individual$m_med)])) <= 10) {
  print(table(individual$m_med, useNA = "ifany"))
}
cat("SD:", round(sd(individual$m_med, na.rm = TRUE), 4),
    " Missing:", sum(is.na(individual$m_med)), "\n")


make_X <- function(dat) {
  X <- model.matrix(
    ~ age + factor(marry) + factor(drinkl) + factor(smoken) +
      factor(gender) + factor(rural) + factor(edu) +
      log_per_gdp + per_bed + per_doc +
      factor(year) + factor(city_code) - 1,
    data = dat
  )
  colnames(X) <- make.names(colnames(X))
  X
}

X_full <- make_X(individual)
if (nrow(X_full) != nrow(individual)) {
  stop("model.matrix() dropped rows. Check for missing covariates.")
}
if (ncol(X_full) < 100) {
  stop("The covariate matrix has only ", ncol(X_full),
       " columns. City/year dummies were probably not created.")
}

n_city_dummies <- sum(grepl("^factor\\.city_code\\.", colnames(X_full)))
n_year_dummies <- sum(grepl("^factor\\.year\\.", colnames(X_full)))
cat("\nCovariate matrix:", nrow(X_full), "x", ncol(X_full), "\n")
cat("City dummies:", n_city_dummies, " Year dummies:", n_year_dummies, "\n")
if (n_city_dummies < 2 || n_year_dummies < 2) {
  stop("City or year fixed effects were not expanded correctly.")
}



alpha_elastic <- 0.5
lambda_rule <- "lambda.1se"
nfolds_elastic <- 5
cat("Elastic net learner: alpha =", alpha_elastic,
    "; lambda rule =", lambda_rule, "\n")

elastic_fit <- function(y, x, ybin = 0) {
  x <- as.data.frame(x)
  ok <- !is.na(y) & complete.cases(x)
  if (sum(ok) < 2) {
    m <- mean(y, na.rm = TRUE)
    return(structure(list(mean = m, mean_y = m, ybin = ybin,
                          keep = rep(FALSE, ncol(x))),
                     class = "elastic_wrap"))
  }
  y <- y[ok]
  x <- x[ok, , drop = FALSE]
  keep <- vapply(x, function(z) length(unique(z)) > 1, logical(1))
  names(keep) <- names(x)
  if (!any(keep) || length(unique(y)) < 2) {
    m <- mean(y)
    return(structure(list(mean = m, mean_y = m, ybin = ybin, keep = keep),
                     class = "elastic_wrap"))
  }
  X <- as.matrix(x[, keep, drop = FALSE])
  nfolds <- min(nfolds_elastic, nrow(X))
  family_use <- if (ybin == 1) "binomial" else "gaussian"
  measure_use <- if (ybin == 1) "deviance" else "mse"

  fit <- if (nfolds >= 3) {
    suppressWarnings(glmnet::cv.glmnet(
      X, y, family = family_use, alpha = alpha_elastic,
      nfolds = nfolds, type.measure = measure_use
    ))
  } else {
    NULL
  }
  if (is.null(fit)) {
    fit <- suppressWarnings(glmnet::glmnet(
      X, y, family = family_use, alpha = alpha_elastic, lambda = 1e-4
    ))
  }
  lambda_use <- if (inherits(fit, "cv.glmnet")) {
    if (lambda_rule == "lambda.min") fit$lambda.min else fit$lambda.1se
  } else {
    1e-4
  }
  if (!is.finite(lambda_use)) {
    lambda_use <- if (inherits(fit, "cv.glmnet")) fit$lambda.min else 1e-4
  }
  if (!is.finite(lambda_use)) lambda_use <- 1e-4
  structure(list(fit = fit, ybin = ybin, keep = keep,
                 lambda = lambda_use, mean_y = mean(y)),
            class = "elastic_wrap")
}

predict.elastic_wrap <- function(object, newdata, onlySL = TRUE, ...) {
  newdata <- as.data.frame(newdata)
  if (!is.null(object[["mean", exact = TRUE]])) {
    return(list(pred = rep(object$mean, nrow(newdata))))
  }
  keep_names <- names(object$keep)[object$keep]
  newdata <- newdata[, keep_names, drop = FALSE]
  pred <- tryCatch(
    predict(object$fit, newx = as.matrix(newdata),
            s = object$lambda, type = "response"),
    error = function(e) rep(object$mean_y, nrow(newdata))
  )
  pred <- as.numeric(pred)
  pred[!is.finite(pred)] <- object$mean_y
  list(pred = pred)
}

dml_total <- function(dat, X, dvar, fold_seed = 42, k = 3) {
  y <- dat$health_pca
  d <- dat[[dvar]]
  ok <- !is.na(y) & !is.na(d)
  y <- y[ok]
  d <- d[ok]
  Xd <- X[ok, , drop = FALSE]
  n <- length(y)
  set.seed(fold_seed)
  fold <- sample(rep(seq_len(k), length.out = n))
  yhat <- dhat <- rep(NA_real_, n)

  for (j in seq_len(k)) {
    tr <- fold != j
    te <- !tr
    fy <- elastic_fit(y[tr], Xd[tr, , drop = FALSE], ybin = 0)
    fd <- elastic_fit(d[tr], Xd[tr, , drop = FALSE], ybin = 0)
    yhat[te] <- predict.elastic_wrap(fy, Xd[te, , drop = FALSE])$pred
    dhat[te] <- predict.elastic_wrap(fd, Xd[te, , drop = FALSE])$pred
  }

  yr <- y - yhat
  dr <- d - dhat
  m <- lm(yr ~ dr)
  V <- vcovCL(m, cluster = dat$city_code[ok], type = "HC1")
  b <- unname(coef(m)["dr"])
  se <- unname(sqrt(diag(V))["dr"])
  c(est = b, se = se, p = 2 * pnorm(-abs(b / se)), n = n)
}

MLfunct_elastic <- function(y, x, d1 = NULL, d2 = NULL,
                            MLmethod = "elasticcv", ybin = 0) {
  if (!is.null(d1) && !is.null(d2)) {
    y <- y[d1 == 1 & d2 == 1]
    x <- x[d1 == 1 & d2 == 1, ]
  }
  if (!is.null(d1) && is.null(d2)) {
    y <- y[d1 == 1]
    x <- x[d1 == 1, ]
  }
  elastic_fit(y = y, x = x, ybin = ybin)
}

env_elastic <- new.env(parent = asNamespace("causalweight"))
env_elastic$MLfunct <- MLfunct_elastic

hdmedalt_elastic <- causalweight:::hdmedalt
body_el <- body(hdmedalt_elastic)
formals(hdmedalt_elastic) <- as.pairlist(
  c(as.list(formals(hdmedalt_elastic)), fold_seed = 1)
)
seed_pos_el <- which(vapply(as.list(body_el),
                            function(e) identical(e, quote(set.seed(1))),
                            logical(1)))
if (length(seed_pos_el) != 1) {
  stop("causalweight:::hdmedalt() no longer contains exactly one set.seed(1). ",
       "The internal API changed; update this wrapper before using it.")
}
body_el[[seed_pos_el]] <- quote(set.seed(fold_seed))
last_pos_el <- length(body_el)
last_expr_el <- paste(deparse(body_el[[last_pos_el]]), collapse = " ")
if (!grepl("^c\\(tot", last_expr_el)) {
  stop("The last expression of hdmedalt() is not the expected c(tot, ...). ",
       "The internal API changed.")
}
body_el[[last_pos_el]] <- quote(
  list(
    temp = c(tot, dir1, dir0, indir1, indir0, my0m0,
             vtot, vdir1, vdir0, vindir1, vindir0, vcontrol,
             sum(selall)),
    y1m1 = y1m1, y1m0 = y1m0, y0m1 = y0m1, y0m0 = y0m0,
    selall = selall, idx = idx, stepsize = stepsize
  )
)
body(hdmedalt_elastic) <- body_el
environment(hdmedalt_elastic) <- env_elastic

# medDML_if(): same point estimates as medDML(), plus influence functions.
medDML_if <- function(y, d, m, x, trim = 0.001, fold_seed = 1,
                      order = 1, multmed = TRUE) {
  if (!isTRUE(multmed)) {
    stop("medDML_if() is written for multmed = TRUE.")
  }
  obj <- hdmedalt_elastic(
    y = y, d = d, m = m, x = x,
    trim = trim, order = order, fewsplits = FALSE,
    normalized = TRUE, MLmethod = "elasticcv", fold_seed = fold_seed
  )

  temp <- obj$temp
  eff  <- temp[1:6]
  se_iid <- sqrt(temp[7:12] / temp[13])
  results <- rbind(
    effect = eff,
    se     = se_iid,
    `p-val` = 2 * pnorm(-abs(eff / se_iid))
  )
  colnames(results) <- c("total", "dir.treat", "dir.control",
                         "indir.treat", "indir.control", "Y(0,M(0))")

  n <- length(d)
  stepsize <- ceiling(n / 3)
  nobs0 <- min(3 * stepsize, n)
  eval_order <- c(
    obj$idx[seq_len(stepsize)],
    obj$idx[(2 * stepsize + 1):nobs0],
    obj$idx[(stepsize + 1):(2 * stepsize)]
  )
  retained_rows <- eval_order[obj$selall == 1]
  if (length(retained_rows) != length(obj$y1m1)) {
    stop("Internal error: influence-function mapping does not match the ",
         "number of retained observations.")
  }
  if_vec <- function(v) {
    out <- rep(NA_real_, n)
    out[retained_rows] <- v
    out
  }

  list(
    results    = results,
    ntrimmed   = n - temp[13],
    n_retained = as.integer(temp[13]),
    rows       = retained_rows,
    IF = list(
      total         = if_vec(obj$y1m1 - obj$y0m0 - eff[1]),
      dir.treat     = if_vec(obj$y1m1 - obj$y0m1 - eff[2]),
      dir.control   = if_vec(obj$y1m0 - obj$y0m0 - eff[3]),
      indir.treat   = if_vec(obj$y1m1 - obj$y1m0 - eff[4]),
      indir.control = if_vec(obj$y0m1 - obj$y0m0 - eff[5])
    )
  )
}


cluster_se <- function(IF, cluster, n_r) {
  ok <- !is.na(IF)
  if (sum(ok) == 0 || n_r <= 0) return(NA_real_)
  sums <- tapply(IF[ok], cluster[ok], sum)
  G <- length(sums)
  if (G <= 1) return(NA_real_)
  sqrt(G / (G - 1) * sum(sums^2)) / n_r
}

cluster_cov <- function(A, B, cluster, n_r) {
  ok <- !is.na(A) & !is.na(B)
  if (sum(ok) == 0 || n_r <= 0) return(NA_real_)
  sA <- tapply(A[ok], cluster[ok], sum)
  sB <- tapply(B[ok], cluster[ok], sum)
  G <- length(sA)
  if (G <= 1) return(NA_real_)
  G / (G - 1) * sum(sA * sB) / n_r^2
}


prop_mediated <- function(fit, cluster) {
  total <- fit$results["effect", "total"]
  indir <- fit$results["effect", "indir.treat"]
  n_r   <- fit$n_retained
  if (!is.finite(total) || abs(total) < 1e-10) {
    return(c(prop = NA_real_, se = NA_real_, lo = NA_real_, hi = NA_real_))
  }
  prop <- indir / total
  IF_prop <- (fit$IF$indir.treat - prop * fit$IF$total) / total
  se <- cluster_se(IF_prop, cluster, n_r)
  c(prop = prop, se = se,
    lo = prop - 1.96 * se, hi = prop + 1.96 * se)
}


run_spec <- function(dat, mvar, label, dvar = "Broad_band_China1",
                     trim = trim_main,
                     fold_seed = seed_main, multmed = TRUE,
                     compute_sensitivity = TRUE) {
  ok <- !is.na(dat[[mvar]]) &
    !is.na(dat$health_pca) &
    !is.na(dat[[dvar]])
  dd <- dat[ok, , drop = FALSE]
  X  <- X_full[dd$row_id, , drop = FALSE]

  fit <- medDML_if(
    y = dd$health_pca, d = dd[[dvar]], m = dd[[mvar]],
    x = X, trim = trim, fold_seed = fold_seed, multmed = multmed
  )

  total_dml <- dml_total(dd, X, dvar, fold_seed = fold_seed)

  r <- fit$results
  est_total <- r["effect", "total"]
  est_dir   <- r["effect", "dir.treat"]
  est_ind   <- r["effect", "indir.treat"]

  se_city <- c(
    total = cluster_se(fit$IF$total, dd$city_code, fit$n_retained),
    dir   = cluster_se(fit$IF$dir.treat, dd$city_code, fit$n_retained),
    indir = cluster_se(fit$IF$indir.treat, dd$city_code, fit$n_retained)
  )
  se_id <- c(
    total = cluster_se(fit$IF$total, dd$ID, fit$n_retained),
    dir   = cluster_se(fit$IF$dir.treat, dd$ID, fit$n_retained),
    indir = cluster_se(fit$IF$indir.treat, dd$ID, fit$n_retained)
  )

  p_city <- 2 * pnorm(-abs(c(total = est_total, dir = est_dir, indir = est_ind) /
                             se_city))
  p_id   <- 2 * pnorm(-abs(c(total = est_total, dir = est_dir, indir = est_ind) /
                             se_id))

  pm <- prop_mediated(fit, dd$city_code)

  total_fit <- lm(dd$health_pca ~ dd[[dvar]] + X)
  V_total <- vcovCL(total_fit, cluster = dd$city_code, type = "HC1")
  total_fe <- unname(coef(total_fit)[2])
  se_total_fe <- sqrt(diag(V_total))[2]

  out <- data.frame(
    spec          = label,
    treatment     = dvar,
    mediator      = mvar,
    N             = nrow(dd),
    N_retained    = fit$n_retained,
    ntrimmed      = fit$ntrimmed,
    total_fe_ols  = total_fe,
    se_total_fe_ols = se_total_fe,
    p_total_fe_ols = 2 * pnorm(-abs(total_fe / se_total_fe)),
    total_dml     = total_dml["est"],
    se_total_dml  = total_dml["se"],
    p_total_dml   = total_dml["p"],
    total_medDML  = est_total,
    total         = est_total,
    dir_treat     = est_dir,
    indir_treat   = est_ind,
    indir_control = r["effect", "indir.control"],
    se_city_total = se_city["total"],
    se_city_dir   = se_city["dir"],
    se_city_indir = se_city["indir"],
    p_city_total  = p_city["total"],
    p_city_dir    = p_city["dir"],
    p_city_indir  = p_city["indir"],
    ci_city_indir_lo = est_ind - 1.96 * se_city["indir"],
    ci_city_indir_hi = est_ind + 1.96 * se_city["indir"],
    se_id_total   = se_id["total"],
    se_id_dir     = se_id["dir"],
    se_id_indir   = se_id["indir"],
    p_id_total    = p_id["total"],
    p_id_dir      = p_id["dir"],
    p_id_indir    = p_id["indir"],
    ci_id_indir_lo = est_ind - 1.96 * se_id["indir"],
    ci_id_indir_hi = est_ind + 1.96 * se_id["indir"],
    prop_med      = pm["prop"],
    se_prop       = pm["se"],
    prop_lo       = pm["lo"],
    prop_hi       = pm["hi"],
    iid_se_indir  = r["se", "indir.treat"],
    iid_p_indir   = r["p-val", "indir.treat"],
    row.names     = NULL
  )

  sens <- NULL
  if (isTRUE(compute_sensitivity)) {
    sens <- sensitivity_analysis(
      fit = fit, dat = dd, X = X, mvar = mvar, label = label,
      trim = trim, dvar = dvar
    )
  }

  list(table = out, fit = fit, data = dd, X = X, sensitivity = sens)
}


sensitivity_analysis <- function(fit, dat, X, mvar, label, trim, dvar,
                                 use_trimmed = FALSE) {

  rows <- if (isTRUE(use_trimmed)) fit$rows else seq_len(nrow(dat))
  m <- dat[[mvar]][rows]
  y <- dat$health_pca[rows]
  d <- dat[[dvar]][rows]
  city <- dat$city_code[rows]

  dat_r <- data.frame(
    m = m, y = y, d = d,
    X[rows, , drop = FALSE],
    check.names = FALSE
  )

  fm <- lm(m ~ d + ., data = dat_r[, c("m", "d", colnames(X))])
  fy <- lm(y ~ d + m + ., data = dat_r[, c("y", "d", "m", colnames(X))])

  a1 <- unname(coef(fm)["d"])
  b1 <- unname(coef(fy)["d"])
  b2 <- unname(coef(fy)["m"])
  sigma_m <- summary(fm)$sigma
  sigma_y <- summary(fy)$sigma
  s <- sigma_y / sigma_m

  acme0 <- a1 * b2
  rho_zero <- -b2 / s
  rho_in_range <- is.finite(rho_zero) && abs(rho_zero) <= 1

  grid <- seq(-0.9, 0.9, by = 0.01)
  acme <- a1 * (b2 + grid * s)
  total_param <- b1 + a1 * b2
  prop <- if (abs(total_param) > 1e-10) acme / total_param else rep(NA_real_, length(grid))


  rho_cross <- NA_real_
  if (any(diff(sign(acme)) != 0)) {
    idx <- which(diff(sign(acme)) != 0)[1]
    rho_cross <- grid[idx] - acme[idx] * (grid[idx + 1] - grid[idx]) /
      (acme[idx + 1] - acme[idx])
  }


  se_b2 <- NA_real_
  ev <- NULL
  ev_txt <- "E-value not computed"
  ev_ok <- tryCatch({
    V <- vcovCL(fy, cluster = city, type = "HC1")
    se_b2 <- sqrt(diag(V))["m"]

    ev <- suppressMessages(evalues.OLS(est = b2, se = se_b2,
                                       sd = sigma_y, delta = delta_sens))
    TRUE
  }, error = function(e) FALSE)

  if (isTRUE(ev_ok) && !is.null(ev)) {
    ev_txt <- paste(capture.output(print(ev)), collapse = " | ")
  }

  list(
    label = label,
    trim = trim,
    n_retained = fit$n_retained,
    n_sensitivity = length(rows),
    a1 = a1, b1 = b1, b2 = b2,
    sigma_m = sigma_m, sigma_y = sigma_y,
    acme0 = acme0, total_param = total_param,
    prop0 = if (abs(total_param) > 1e-10) acme0 / total_param else NA_real_,
    rho_zero = rho_zero,
    rho_in_range = rho_in_range,
    rho_cross = rho_cross,
    grid = data.frame(rho = grid, acme = acme, prop_med = prop),
    evalue = ev,
    evalue_text = ev_txt,
    se_b2 = se_b2
  )
}


cat("\n", paste(rep("=", 78), collapse = ""), "\n", sep = "")
cat("MAIN ANALYSIS AND ROBUSTNESS\n")
cat(paste(rep("=", 78), collapse = ""), "\n", sep = "")

spec_list <- list(
  list(mvar = "m_med", dvar = "Broad_band_China1",
       label = "Main: contemporaneous m (freq_social10), D = Broad_band_China1"),
  list(mvar = "m_med", dvar = "Broad_band_China2",
       label = "Robustness: contemporaneous m (freq_social10), D = Broad_band_China2")
)

spec_results <- lapply(spec_list, function(s) {
  run_spec(individual, s$mvar, s$label, dvar = s$dvar,
           trim = trim_main, fold_seed = seed_main,
           compute_sensitivity = FALSE)
})
names(spec_results) <- vapply(spec_list,
                              function(s) paste(s$mvar, s$dvar, sep = "_"),
                              character(1))

table_main <- do.call(rbind, lapply(spec_results, `[[`, "table"))
rownames(table_main) <- NULL

table_main$total_source <- "DML total (same sample)"
table_main$total_report <- table_main$total_dml
table_main$indirect_report <- table_main$indir_treat
table_main$direct_implied <- table_main$total_report - table_main$indirect_report
table_main$dir_medDML <- table_main$dir_treat


table_main$total_p_report <- table_main$p_total_dml
table_main$se_total_report <- table_main$se_total_dml

table_main$direct_se_approx <- sqrt(
  table_main$se_total_report^2 + table_main$se_city_indir^2
)
table_main$direct_p_approx <- 2 * pnorm(
  -abs(table_main$direct_implied / table_main$direct_se_approx)
)

table_out <- data.frame(
  specification   = table_main$spec,
  total_effect    = table_main$total_report,
  total_se        = table_main$se_total_report,
  total_p         = table_main$total_p_report,
  direct_effect   = table_main$direct_implied,
  direct_se       = table_main$direct_se_approx,
  direct_p        = table_main$direct_p_approx,
  indirect_effect = table_main$indirect_report,
  indirect_se     = table_main$se_city_indir,
  indirect_p      = table_main$p_city_indir,
  row.names       = NULL
)

cat("\nPaper table (Total, Direct, Indirect; SE and p):\n")
print(table_out, digits = 4, row.names = FALSE)

write.csv(table_out,
          file.path(out_dir, "Mediation.csv"),
          row.names = FALSE)

cat("\nInterpretation of the main row:\n")
main_row <- table_main[table_main$spec == "Main: contemporaneous m (freq_social10), D = Broad_band_China1", ]
cat(sprintf("  Indirect effect = %.6f; city-clustered SE = %.6f, p = %.4f; ",
            main_row$indir_treat, main_row$se_city_indir, main_row$p_city_indir))
cat(sprintf("individual-clustered SE = %.6f, p = %.4f.\n",
            main_row$se_id_indir, main_row$p_id_indir))
cat(sprintf("  N = %d, N retained after trimming = %d (%.1f%% trimmed).\n",
            main_row$N, main_row$N_retained,
            100 * main_row$ntrimmed / main_row$N))
cat(sprintf("  Total effect: DML total (same sample) = %.4f (SE %.4f, p = %.4f); same-sample FE OLS = %.4f (p = %.4f); medDML internal total = %.4f.\n",
            main_row$total_dml, main_row$se_total_dml, main_row$p_total_dml,
            main_row$total_fe_ols, main_row$p_total_fe_ols, main_row$total_medDML))
cat(sprintf("  Reported decomposition: total = %.4f (%s); direct (implied = total - indirect) = %.4f; indirect = %.4f.\n",
            main_row$total_report, main_row$total_source,
            main_row$direct_implied, main_row$indirect_report))
cat(sprintf("  For audit only: medDML separately estimated direct = %.4f (not used; it does not match the main DDML total decomposition).\n",
            main_row$dir_medDML))
