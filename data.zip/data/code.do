*The effect of digital infrastructure development on health and health inequality: A double machine learning model study



*Table 1
use "C:\Users\10458\Desktop\data\main_data.dta", clear
sum health_pca rif_ci_pca ses age log_per_gdp per_bed per_doc
foreach v of varlist gender edu rural marry drinkl smoken {
	tab `v'
}

use "C:\Users\10458\Desktop\data\main_data.dta", clear
keep if Broad_band_China1 == 0
sum health_pca rif_ci_pca ses age log_per_gdp per_bed per_doc
foreach v of varlist gender edu rural marry drinkl smoken {
	tab `v'
}

use "C:\Users\10458\Desktop\data\main_data.dta", clear
keep if Broad_band_China1 == 1
sum health_pca rif_ci_pca ses age log_per_gdp per_bed per_doc
foreach v of varlist gender edu rural marry drinkl smoken {
	tab `v'
}


*Table 2 
use"C:\Users\10458\Desktop\data\main_data.dta",clear
global Y health_pca
global X   i.year i.city_code
global D Broad_band_China1
set seed 42    
local py_seed 42    
ddml init partial, kfolds(3) 
ddml E[D|X]: pystacked $D $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster city_code)   

use"C:\Users\10458\Desktop\data\main_data.dta",clear
global Y health_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl i.year i.city_code
global D Broad_band_China1
set seed 42    
local py_seed 42    
ddml init partial, kfolds(3) 
ddml E[D|X]: pystacked $D $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster city_code) 

use"C:\Users\10458\Desktop\data\main_data.dta",clear
global Y health_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc i.year i.city_code
global D Broad_band_China1
set seed 42    
local py_seed 42 
ddml init partial, kfolds(3) 
ddml E[D|X]: pystacked $D $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster city_code)


*Table 4
use"C:\Users\10458\Desktop\data\main_data.dta",clear
keep if age <70
global Y health_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc i.year i.city_code
global D Broad_band_China1
set seed 42    
local py_seed 42   
ddml init partial, kfolds(3)
ddml E[D|X]: pystacked $D $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster city_code)   

use"C:\Users\10458\Desktop\data\main_data.dta",clear
keep if age >=70
global Y health_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc i.year i.city_code
global D Broad_band_China1
set seed 42    
local py_seed 42    
ddml init partial, kfolds(3)
ddml E[D|X]: pystacked $D $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster city_code)  

use"C:\Users\10458\Desktop\data\main_data.dta",clear
keep if region == "东部" | region =="东北"
global Y health_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc   i.year i.city_code
global D Broad_band_China1
set seed 42    
local py_seed 42    
ddml init partial, kfolds(3)
ddml E[D|X]: pystacked $D $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster city_code)   

use"C:\Users\10458\Desktop\data\main_data.dta",clear
keep if region == "中部" | region == "西部"
global Y health_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc   i.year i.city_code
global D Broad_band_China1
set seed 42    
local py_seed 42    
ddml init partial, kfolds(3)
ddml E[D|X]: pystacked $D $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster city_code)   


*Table 5 
use"C:\Users\10458\Desktop\data\main_data.dta",clear
xtile ses_q = ses, nq(4)

global Y health_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc i.city_code i.year
global D Broad_band_China1
set seed 42
local py_seed 42
forvalues q = 1/4 {
    ddml init partial, kfolds(3)
    ddml E[D|X]: pystacked $D $X if ses_q == `q', type(reg) method(elasticcv) pyseed(`py_seed')
	ddml E[Y|X]: pystacked $Y $X if ses_q == `q', type(reg) method(elasticcv) pyseed(`py_seed')
	ddml crossfit
    ddml estimate if ses_q == `q', vce(cluster city_code)
}


*Table 6
use"C:\Users\10458\Desktop\data\main_data.dta",clear
global Y rif_ci_pca
global X   i.year i.city_code
global D Broad_band_China1
set seed 42    
local py_seed 42   
ddml init partial, kfolds(3) 
ddml E[D|X]: pystacked $D $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster city_code)   

use"C:\Users\10458\Desktop\data\main_data.dta",clear
global Y rif_ci_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl i.year i.city_code
global D Broad_band_China1
set seed 42    
local py_seed 42    
ddml init partial, kfolds(3) 
ddml E[D|X]: pystacked $D $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster city_code)    

use"C:\Users\10458\Desktop\data\main_data.dta",clear
global Y rif_ci_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc  i.year i.city_code
global D Broad_band_China1
set seed 42   
local py_seed 42   
ddml init partial, kfolds(3) 
ddml E[D|X]: pystacked $D $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster city_code)      


*Table S1
use"C:\Users\10458\Desktop\data\main_data.dta",clear
global Y health_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc  i.year i.city_code
global D Broad_band_China1
set seed 42    
local py_seed 42    
ddml init partial, kfolds(4) 
ddml E[D|X]: pystacked $D $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster city_code)   

use"C:\Users\10458\Desktop\data\main_data.dta",clear
global Y health_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc i.year i.city_code
global D Broad_band_China1
set seed 42    
local py_seed 42   
ddml init partial, kfolds(5) 
ddml E[D|X]: pystacked $D $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster city_code)   

use"C:\Users\10458\Desktop\data\main_data.dta",clear
global Y health_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc   i.year i.city_code
global D Broad_band_China1
set seed 42 
local py_seed 42    
ddml init partial, kfolds(6) 
ddml E[D|X]: pystacked $D $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster city_code)     

use"C:\Users\10458\Desktop\data\main_data.dta",clear
global Y health_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc i.year i.city_code
global D Broad_band_China1
set seed 42  
local py_seed 42   
ddml init partial, kfolds(3) 
ddml E[D|X]: pystacked $D $X, type(reg) method(lassocv) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(lassocv) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster city_code)     

use"C:\Users\10458\Desktop\data\main_data.dta",clear
global Y health_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc i.year i.city_code
global D Broad_band_China1
set seed 42    
local py_seed 42    
ddml init partial, kfolds(3) reps(20)
ddml E[D|X]: pystacked $D $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster city_code)   

use"C:\Users\10458\Desktop\data\main_data.dta",clear
global Y health_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc i.year i.city_code
global D Broad_band_China1
set seed 123   
local py_seed 123   
ddml init partial, kfolds(3)
ddml E[D|X]: pystacked $D $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster city_code)   


*Table S2
use"C:\Users\10458\Desktop\data\main_data.dta",clear
winsor2 health_pca,cuts(1 99)
winsor2 age, cuts(1 99)
winsor2 log_per_gdp ,cuts(1 99)
winsor2 per_bed ,cuts(1 99)
winsor2 per_doc ,cuts(1 99)
global Y health_pca_w
global X age_w i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp_w per_bed_w per_doc_w i.city_code i.year 
global D Broad_band_China1
set seed 42    
local py_seed 42   
ddml init partial, kfolds(3)
ddml E[D|X]: pystacked $D $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster city_code)  

use"C:\Users\10458\Desktop\data\main_data.dta",clear
winsor2 health_pca,cuts(5 95)
winsor2 age, cuts(5 95)
winsor2 log_per_gdp ,cuts(5 95)
winsor2 per_bed ,cuts(5 95)
winsor2 per_doc ,cuts(5 95)
global Y health_pca_w
global X age_w i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp_w per_bed_w per_doc_w  i.city_code i.year 
global D Broad_band_China1
set seed 42    
local py_seed 42    
ddml init partial, kfolds(3)
ddml E[D|X]: pystacked $D $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster city_code)   

use"C:\Users\10458\Desktop\data\main_data.dta",clear
drop if city=="北京市"
drop if city=="天津市"
drop if city=="上海市"
drop if city=="重庆市"
global Y health_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc i.year i.city_code
global D Broad_band_China1
set seed 42  
local py_seed 42    
ddml init partial, kfolds(3) 
ddml E[D|X]: pystacked $D $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster city_code)  

use"C:\Users\10458\Desktop\data\main_data.dta",clear
gen age_2 = age ^ 2
gen log_per_gdp_2 = log_per_gdp ^ 2
gen per_bed_2 = per_bed ^2
gen per_doc_2 = per_doc ^2
global Y health_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc age_2 log_per_gdp_2 per_bed_2 per_doc_2  i.year i.city_code
global D Broad_band_China1
set seed 42   
local py_seed 42    
ddml init partial, kfolds(3) 
ddml E[D|X]: pystacked $D $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster city_code)   

use"C:\Users\10458\Desktop\data\main_data.dta",clear
global Y health_ew
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc i.year i.city_code
global D Broad_band_China1
set seed 42    
local py_seed 42    
ddml init partial, kfolds(3)
ddml E[D|X]: pystacked $D $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster city_code)   


*Table S3
use"C:\Users\10458\Desktop\data\ipw_data.dta",clear

reg health_pca Broad_band_China1 age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc  i.year i.city_code, vce(cluster city_code)

reg health_pca Broad_band_China1 age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc i.year i.city_code [pw = ipw_stab], vce(cluster city_code)

reg health_pca Broad_band_China1 age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc i.year i.city_code [pweight = ipw_trunc], vce(cluster city_code)


*Table S4
use"C:\Users\10458\Desktop\data\main_data.dta",clear
gen IV = p_tele_num * year
global Y health_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc i.year i.city_code
global D Broad_band_China1
global Z IV
set seed 42  
ddml init iv, kfolds(3)  
ddml E[Y|X]: pystacked $Y $X, type(reg) method(elasticcv)
ddml E[D|X]: pystacked $D $X, type(reg) method(elasticcv)
ddml E[Z|X]: pystacked $Z $X, type(reg) method(elasticcv)
ddml crossfit
ddml estimate, vce(cluster city_code)    
ivreg2 Y1_pystacked_1 (D1_pystacked_1 = Z1_pystacked_1),nocons robust first   


*Table S6
use"C:\Users\10458\Desktop\data\main_data.dta",clear
global Y rif_ci_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc i.year i.city_code
global D Broad_band_China1
set seed 42   
local py_seed 42 
ddml init partial, kfolds(4) 
ddml E[D|X]: pystacked $D $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster city_code)     

use"C:\Users\10458\Desktop\data\main_data.dta",clear
global Y rif_ci_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc  i.year i.city_code
global D Broad_band_China1
set seed 42  
local py_seed 42    
ddml init partial, kfolds(5) 
ddml E[D|X]: pystacked $D $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster city_code)   

use"C:\Users\10458\Desktop\data\main_data.dta",clear
global Y rif_ci_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc i.year i.city_code
global D Broad_band_China1
set seed 42    
local py_seed 42   
ddml init partial, kfolds(6) 
ddml E[D|X]: pystacked $D $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster city_code)    

use"C:\Users\10458\Desktop\data\main_data.dta",clear
global Y rif_ci_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc i.year i.city_code
global D Broad_band_China1
set seed 42    
local py_seed 42   
ddml init partial, kfolds(3) 
ddml E[D|X]: pystacked $D $X, type(reg) method(lassocv) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(lassocv) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster city_code)   

use"C:\Users\10458\Desktop\data\main_data.dta",clear
global Y rif_ci_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc i.year i.city_code
global D Broad_band_China1
set seed 42   
local py_seed 42   
ddml init partial, kfolds(3) reps(20)
ddml E[D|X]: pystacked $D $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster city_code)     

use"C:\Users\10458\Desktop\data\main_data.dta",clear
global Y rif_ci_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc i.year i.city_code
global D Broad_band_China1
set seed 123 
local py_seed 123    
ddml init partial, kfolds(3)
ddml E[D|X]: pystacked $D $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster city_code)   


*Table S7
use"C:\Users\10458\Desktop\data\main_data.dta",clear
winsor2 rif_ci_pca,cuts(1 99)
winsor2 age, cuts(1 99)
winsor2 log_per_gdp ,cuts(1 99)
winsor2 per_bed ,cuts(1 99)
winsor2 per_doc ,cuts(1 99)
global Y rif_ci_pca_w
global X age_w i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp_w per_bed_w per_doc_w i.city_code i.year 
global D Broad_band_China1
set seed 42   
local py_seed 42   
ddml init partial, kfolds(3)
ddml E[D|X]: pystacked $D $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster city_code) 

use"C:\Users\10458\Desktop\data\main_data.dta",clear
winsor2 rif_ci_pca,cuts(5 95)
winsor2 age, cuts(5 95)
winsor2 log_per_gdp ,cuts(5 95)
winsor2 per_bed ,cuts(5 95)
winsor2 per_doc ,cuts(5 95)
global Y rif_ci_pca_w
global X age_w i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp_w per_bed_w per_doc_w i.city_code i.year 
global D Broad_band_China1
set seed 42   
local py_seed 42    
ddml init partial, kfolds(3)
ddml E[D|X]: pystacked $D $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster city_code)   

use"C:\Users\10458\Desktop\data\main_data.dta",clear
drop if city=="北京市"
drop if city=="天津市"
drop if city=="上海市"
drop if city=="重庆市"
global Y rif_ci_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc  i.year i.city_code
global D Broad_band_China1
set seed 42    
local py_seed 42    
ddml init partial, kfolds(3) 
ddml E[D|X]: pystacked $D $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster city_code)   

use"C:\Users\10458\Desktop\data\main_data.dta",clear
gen age_2 = age ^ 2
gen log_per_gdp_2 = log_per_gdp ^ 2
gen per_bed_2 = per_bed ^2
gen per_doc_2 = per_doc ^2
global Y rif_ci_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc age_2 log_per_gdp_2 per_bed_2 per_doc_2  i.year i.city_code
global D Broad_band_China1
set seed 42
local py_seed 42    
ddml init partial, kfolds(3) 
ddml E[D|X]: pystacked $D $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster city_code)    

use"C:\Users\10458\Desktop\data\main_data.dta",clear
global Y rif_ci_ew
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc i.year i.city_code
global D Broad_band_China1
set seed 42    
local py_seed 42  
ddml init partial, kfolds(3)
ddml E[D|X]: pystacked $D $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster city_code)  


*Table S8
use"C:\Users\10458\Desktop\data\ipw_data.dta",clear

reg rif_ci_pca Broad_band_China1 age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc  i.year i.city_code, vce(cluster city_code)

reg rif_ci_pca Broad_band_China1 age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc i.year i.city_code [pw = ipw_stab], vce(cluster city_code)

reg rif_ci_pca Broad_band_China1 age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc i.year i.city_code [pweight = ipw_trunc], vce(cluster city_code)


*Table S9
use"C:\Users\10458\Desktop\data\main_data.dta",clear
gen IV = p_tele_num * year
global Y rif_ci_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc i.year i.city_code
global D Broad_band_China1
global Z IV
set seed 42  
ddml init iv, kfolds(3)  
ddml E[Y|X]: pystacked $Y $X, type(reg) method(elasticcv)
ddml E[D|X]: pystacked $D $X, type(reg) method(elasticcv)
ddml E[Z|X]: pystacked $Z $X, type(reg) method(elasticcv)
ddml crossfit
ddml estimate, vce(cluster city_code)    
ivreg2 Y1_pystacked_1 (D1_pystacked_1 = Z1_pystacked_1),nocons robust first   


*Figure S1 -S4
use"C:\Users\10458\Desktop\data\main_data.dta",clear

encode ID, gen(ID_num)
xtset ID_num year

gen aaa = year if Broad_band_China1 == 1
bysort ID: egen action1 = min(aaa)
drop aaa

gen never = (action1 == .)

gen pd = year - action1

forvalues i = 7(-1)2{
    gen pre_`i' = (pd == -`i')
}
gen pre_1 = (pd == -1)   
gen current = (pd == 0)
forvalues j = 1(1)3 {
    gen post_`j' = (pd == `j')
}

*Figure S1
reghdfe health_pca  pre_5 pre_3 current post_3 age i.gender i.rural i.marry i.edu i.smoken i.drinkl  log_per_gdp per_bed per_doc,  absorb(year city_code) vce(cluster city_code)
coefplot, ///
    keep(pre_5 pre_4 pre_3  current post_3 ) ///
    vertical yline(0) ///
    ytitle("coefficient") xtitle("years relative to policy adoption") ///
    addplot(line @b @at, lcolor(black)) ///
    ciopts(recast(rcap) lpattern(dash) msize(medium)) ///
    scheme(s1mono) levels(90) ///
    coeflabels(pre_5 = "-5" pre_3 = "-3"  current = "0" ///
               post_3 = "3" ) ///
    xline(0, lp(shortdash))  

*Figure S2
reghdfe health_pca Broad_band_China1 age i.gender i.rural i.marry i.edu i.smoken i.drinkl  log_per_gdp per_bed per_doc  , absorb(year city_code) vce(cluster city_code)
estimates store placebo
didplacebo placebo, treatvar(Broad_band_China1) pbotime(2(1)6) 

*Figure S3
reghdfe rif_ci_pca pre_5 pre_3 current post_3 age i.gender i.rural i.marry i.edu i.smoken i.drinkl  log_per_gdp per_bed per_doc, absorb(year city_code) vce(cluster city_code)
coefplot, ///
    keep(pre_5 pre_4 pre_3 current post_3) ///
    vertical yline(0) ///
    ytitle("coefficient") xtitle("years relative to policy adoption") ///
    addplot(line @b @at, lcolor(black)) ///
    ciopts(recast(rcap) lpattern(dash) msize(medium)) ///
    scheme(s1mono) levels(90) ///
    coeflabels(pre_5 = "-5" pre_3 = "-3"  current = "0" ///
               post_3 = "3" ) ///
    xline(0, lp(shortdash))  

*Figure S4
reghdfe rif_ci_pca Broad_band_China1 age i.gender i.rural i.marry i.edu i.smoken i.drinkl  log_per_gdp per_bed per_doc, absorb(year city_code) vce(cluster city_code)
estimates store did
didplacebo did, treatvar(Broad_band_China1) pbotime(2(1)6)    


