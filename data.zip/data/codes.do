*The effect of digital infrastructure development on health and health inequality: A double machine learning model study

********************************************
*Table 1 
********************************************
* Total sample
use "C:\Users\10458\Desktop\data\individual.dta", clear
summarize health_pca rif_ci_pca hhcperc Broad_band_China1 age gender rural marry edu smoken drinkl log_per_gdp per_bed per_doc

* Control group
use "C:\Users\10458\Desktop\data\individual.dta", clear
keep if Broad_band_China1 == 0
summarize health_pca rif_ci_pca hhcperc Broad_band_China1 age gender rural marry edu smoken drinkl log_per_gdp per_bed per_doc

* Treatment group
use "C:\Users\10458\Desktop\data\individual.dta", clear
keep if Broad_band_China1 == 1
summarize health_pca rif_ci_pca hhcperc Broad_band_China1 age gender rural marry edu smoken drinkl log_per_gdp per_bed per_doc



********************************************
*Table 2
********************************************
use "C:\Users\10458\Desktop\data\individual.dta", clear
global Y health_pca
global X    age i.gender i.rural i.marry i.edu i.smoken i.drinkl i.city_code i.year
global D Broad_band_China1
set seed 42    
local py_seed 42   
ddml init partial, kfolds(4)
ddml E[D|X]: pystacked $D $X, type(reg) method(svm) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(svm) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster ID)

use "C:\Users\10458\Desktop\data\individual.dta", clear
global Y health_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc  age_2 log_per_gdp_2 per_bed_2 per_doc_2 
global D Broad_band_China1
set seed 42    
local py_seed 42
ddml init partial, kfolds(4)
ddml E[D|X]: pystacked $D $X, type(reg) method(svm) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(svm) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster ID)  

use "C:\Users\10458\Desktop\data\individual.dta", clear
global Y health_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc  age_2 log_per_gdp_2 per_bed_2 per_doc_2 i.city_code i.year
global D Broad_band_China1
set seed 42    
local py_seed 42  
ddml init partial, kfolds(4)
ddml E[D|X]: pystacked $D $X, type(reg) method(svm) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(svm) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster ID) 



********************************************
*Table 4
********************************************
use "C:\Users\10458\Desktop\data\individual.dta", clear
keep if age <60
global Y health_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc  age_2 log_per_gdp_2 per_bed_2 per_doc_2 i.city_code i.year
global D Broad_band_China1
set seed 42    //设置STATA的种子值
local py_seed 42    // 定义一个局部宏，用于Python的种子，方便统一管理
ddml init partial, kfolds(4)
ddml E[D|X]: pystacked $D $X, type(reg) method(svm) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(svm) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster ID)  

use "C:\Users\10458\Desktop\data\individual.dta", clear
keep if age >=60
global Y health_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc  age_2 log_per_gdp_2 per_bed_2 per_doc_2 i.city_code i.year
global D Broad_band_China1
set seed 42    
local py_seed 42    
ddml init partial, kfolds(4)
ddml E[D|X]: pystacked $D $X, type(reg) method(svm) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(svm) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster ID)     

use "C:\Users\10458\Desktop\data\individual.dta", clear
keep if region == "东部"  | region =="东北"
global Y health_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc  age_2 log_per_gdp_2 per_bed_2 per_doc_2 i.city_code i.year
global D Broad_band_China1
set seed 42    
local py_seed 42  
ddml init partial, kfolds(4)
ddml E[D|X]: pystacked $D $X, type(reg) method(svm) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(svm) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster ID)  

use "C:\Users\10458\Desktop\data\individual.dta", clear
keep if region == "中部" | region =="西部"
global Y health_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc  age_2 log_per_gdp_2 per_bed_2 per_doc_2 i.city_code i.year
global D Broad_band_China1
set seed 42    
local py_seed 42   
ddml init partial, kfolds(4)
ddml E[D|X]: pystacked $D $X, type(reg) method(svm) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(svm) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster ID)     



********************************************
*Table 5
********************************************
use "C:\Users\10458\Desktop\data\individual.dta", clear
replace hhcperc = 0.001 if hhcperc == 0
g interact = Broad_band_China1 * log(hhcperc)
global Y health_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc  age_2 log_per_gdp_2 per_bed_2 per_doc_2 i.city_code i.year
global D interact
set seed 42    
local py_seed 42    
ddml init partial, kfolds(4)
ddml E[D|X]: pystacked $D $X, type(reg) method(svm) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(svm) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster ID)   



********************************************
*Table 6
********************************************
use "C:\Users\10458\Desktop\data\individual.dta", clear
global Y rif_ci_pca
global X    age i.gender i.rural i.marry i.edu i.smoken i.drinkl i.city_code i.year
global D Broad_band_China1
set seed 42    
local py_seed 42   
ddml init partial, kfolds(4)
ddml E[D|X]: pystacked $D $X, type(reg) method(svm) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(svm) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster ID)    

use "C:\Users\10458\Desktop\data\individual.dta", clear
global Y rif_ci_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc  age_2 log_per_gdp_2 per_bed_2 per_doc_2 
global D Broad_band_China1
set seed 42   
local py_seed 42    
ddml init partial, kfolds(4)
ddml E[D|X]: pystacked $D $X, type(reg) method(svm) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(svm) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster ID)  

use "C:\Users\10458\Desktop\data\individual.dta", clear
global Y rif_ci_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc  age_2 log_per_gdp_2 per_bed_2 per_doc_2 i.city_code i.year
global D Broad_band_China1
set seed 42    //设置STATA的种子值
local py_seed 42    // 定义一个局部宏，用于Python的种子，方便统一管理
ddml init partial, kfolds(4)
ddml E[D|X]: pystacked $D $X, type(reg) method(svm) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(svm) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster ID)    



********************************************
*Table S1
********************************************
use "C:\Users\10458\Desktop\data\individual.dta", clear
global Y health_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc  age_2 log_per_gdp_2 per_bed_2 per_doc_2 i.city_code i.year
global D Broad_band_China1
set seed 42   
local py_seed 42    
ddml init partial, kfolds(3)
ddml E[D|X]: pystacked $D $X, type(reg) method(svm) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(svm) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster ID)  

use "C:\Users\10458\Desktop\data\individual.dta", clear
global Y health_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc  age_2 log_per_gdp_2 per_bed_2 per_doc_2 i.city_code i.year
global D Broad_band_China1
set seed 42   
local py_seed 42  
ddml init partial, kfolds(5)
ddml E[D|X]: pystacked $D $X, type(reg) method(svm) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(svm) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster ID)  

use "C:\Users\10458\Desktop\data\individual.dta", clear
global Y health_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc  age_2 log_per_gdp_2 per_bed_2 per_doc_2 i.city_code i.year
global D Broad_band_China1
set seed 42    
local py_seed 42    
ddml init partial, kfolds(6)
ddml E[D|X]: pystacked $D $X, type(reg) method(svm) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(svm) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster ID)   

use "C:\Users\10458\Desktop\data\individual.dta", clear
global Y health_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc  age_2 log_per_gdp_2 per_bed_2 per_doc_2 i.city_code i.year
global D Broad_band_China1
set seed 42   
local py_seed 42   
ddml init partial, kfolds(4)
ddml E[D|X]: pystacked $D $X, type(reg) method(lassocv) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(lassocv) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster ID)  

use "C:\Users\10458\Desktop\data\individual.dta", clear
global Y health_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc  age_2 log_per_gdp_2 per_bed_2 per_doc_2 i.city_code i.year
global D Broad_band_China1
set seed 42  
local py_seed 42   
ddml init partial, kfolds(4)
ddml E[D|X]: pystacked $D $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster ID)     

use "C:\Users\10458\Desktop\data\individual.dta", clear
global Y health_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc  age_2 log_per_gdp_2 per_bed_2 per_doc_2 i.city_code i.year
global D Broad_band_China1
set seed 42   
local py_seed 42   
ddml init partial, kfolds(4)
ddml E[D|X]: pystacked $D $X, type(reg) method(nnet) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(nnet) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster ID)   

use "C:\Users\10458\Desktop\data\individual.dta", clear
global Y health_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc  age_2 log_per_gdp_2 per_bed_2 per_doc_2 i.city_code i.year
global D Broad_band_China1
set seed 42   
local py_seed 42   
ddml init partial, kfolds(4) reps(10)
ddml E[D|X]: pystacked $D $X, type(reg) method(svm) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(svm) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster ID)    

use "C:\Users\10458\Desktop\data\individual.dta", clear
global Y health_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc  age_2 log_per_gdp_2 per_bed_2 per_doc_2 i.city_code i.year
global D Broad_band_China1
set seed 123    
local py_seed 123   
ddml init partial, kfolds(4)
ddml E[D|X]: pystacked $D $X, type(reg) method(svm) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(svm) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster ID)   



********************************************
*Table S2
********************************************
use "C:\Users\10458\Desktop\data\individual.dta", clear
winsor2 health_pca,cuts(1 99)
winsor2 age, cuts(1 99)
winsor2 age_2, cuts(1 99)
winsor2 log_per_gdp ,cuts(1 99)
winsor2 log_per_gdp_2 ,cuts(1 99)
winsor2 per_bed ,cuts(1 99)
winsor2 per_bed_2 ,cuts(1 99)
winsor2 per_doc ,cuts(1 99)
winsor2 per_doc_2 ,cuts(1 99)
global Y health_pca_w
global X age_w i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp_w per_bed_w per_doc_w  age_2_w log_per_gdp_2_w per_bed_2_w per_doc_2_w i.city_code i.year 
global D Broad_band_China1
set seed 42 
local py_seed 42    
ddml init partial, kfolds(4)
ddml E[D|X]: pystacked $D $X, type(reg) method(svm) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(svm) pyseed(`py_seed') 
ddml crossfit
ddml estimate,vce(cluster ID)  

use "C:\Users\10458\Desktop\data\individual.dta", clear
drop if city=="北京市"
drop if city=="天津市"
drop if city=="上海市"
drop if city=="重庆市"
global Y health_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc age_2  log_per_gdp_2 per_bed_2 per_doc_2 i.city_code i.year 
global D Broad_band_China1
set seed 42    
local py_seed 42    
ddml init partial, kfolds(4)
ddml E[D|X]: pystacked $D $X, type(reg) method(svm) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(svm) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster ID) 

use "C:\Users\10458\Desktop\data\individual.dta", clear
g iv = post_tele_ser*year
global Y health_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc age_2  log_per_gdp_2 per_bed_2 per_doc_2 i.city_code i.year 
global D Broad_band_China1
global Z iv
set seed 42  
ddml init iv, kfolds(4)  
ddml E[Y|X]: pystacked $Y $X, type(reg) method(svm)
ddml E[D|X]: pystacked $D $X, type(reg) method(svm)
ddml E[Z|X]: pystacked $Z $X, type(reg) method(svm)
ddml crossfit
ddml estimate, vce(cluster ID)    

use "C:\Users\10458\Desktop\data\individual.dta", clear
global Y health
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc  age_2 log_per_gdp_2 per_bed_2 per_doc_2 i.city_code i.year
global D Broad_band_China1
set seed 42    
local py_seed 42   
ddml init partial, kfolds(4)
ddml E[D|X]: pystacked $D $X, type(reg) method(svm) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(svm) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster ID)      



********************************************
*Table S3
********************************************
use "C:\Users\10458\Desktop\data\individual.dta", clear
global Y social10
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc  age_2 log_per_gdp_2 per_bed_2 per_doc_2 i.city_code i.year
global D Broad_band_China1
set seed 42    
local py_seed 42   
ddml init partial, kfolds(4)
ddml E[D|X]: pystacked $D $X, type(reg) method(svm) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(svm) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster ID)    

use "C:\Users\10458\Desktop\data\individual.dta", clear
global Y satlife
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc  age_2 log_per_gdp_2 per_bed_2 per_doc_2 i.city_code i.year
global D Broad_band_China1
set seed 42 
local py_seed 42   
ddml init partial, kfolds(4)
ddml E[D|X]: pystacked $D $X, type(reg) method(svm) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(svm) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster ID)      



********************************************
*Table S4
********************************************
use "C:\Users\10458\Desktop\data\individual.dta", clear
global Y rif_ci_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc  age_2 log_per_gdp_2 per_bed_2 per_doc_2 i.city_code i.year
global D Broad_band_China1
set seed 42    
local py_seed 42    
ddml init partial, kfolds(3)
ddml E[D|X]: pystacked $D $X, type(reg) method(svm) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(svm) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster ID)  

use "C:\Users\10458\Desktop\data\individual.dta", clear
global Y rif_ci_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc  age_2 log_per_gdp_2 per_bed_2 per_doc_2 i.city_code i.year
global D Broad_band_China1
set seed 42   
local py_seed 42   
ddml init partial, kfolds(5)
ddml E[D|X]: pystacked $D $X, type(reg) method(svm) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(svm) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster ID)   

use "C:\Users\10458\Desktop\data\individual.dta", clear
global Y rif_ci_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc  age_2 log_per_gdp_2 per_bed_2 per_doc_2 i.city_code i.year
global D Broad_band_China1
set seed 42    
local py_seed 42    
ddml init partial, kfolds(6)
ddml E[D|X]: pystacked $D $X, type(reg) method(svm) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(svm) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster ID)  

use "C:\Users\10458\Desktop\data\individual.dta", clear
global Y rif_ci_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc  age_2 log_per_gdp_2 per_bed_2 per_doc_2 i.city_code i.year
global D Broad_band_China1
set seed 42   
local py_seed 42  
ddml init partial, kfolds(4)
ddml E[D|X]: pystacked $D $X, type(reg) method(lassocv) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(lassocv) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster ID)   

use "C:\Users\10458\Desktop\data\individual.dta", clear
global Y rif_ci_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc  age_2 log_per_gdp_2 per_bed_2 per_doc_2 i.city_code i.year
global D Broad_band_China1
set seed 42
local py_seed 42   
ddml init partial, kfolds(4)
ddml E[D|X]: pystacked $D $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(elasticcv) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster ID)  

use "C:\Users\10458\Desktop\data\individual.dta", clear
global Y rif_ci_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc  age_2 log_per_gdp_2 per_bed_2 per_doc_2 i.city_code i.year
global D Broad_band_China1
set seed 42    
local py_seed 42    
ddml init partial, kfolds(4)
ddml E[D|X]: pystacked $D $X, type(reg) method(nnet) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(nnet) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster ID)  

use "C:\Users\10458\Desktop\data\individual.dta", clear
global Y rif_ci_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc  age_2 log_per_gdp_2 per_bed_2 per_doc_2 i.city_code i.year
global D Broad_band_China1
set seed 42    
local py_seed 42
ddml init partial, kfolds(4) reps(10)
ddml E[D|X]: pystacked $D $X, type(reg) method(svm) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(svm) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster ID)

use "C:\Users\10458\Desktop\data\individual.dta", clear
global Y rif_ci_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc  age_2 log_per_gdp_2 per_bed_2 per_doc_2 i.city_code i.year
global D Broad_band_China1
set seed 123    
local py_seed 123
ddml init partial, kfolds(4)
ddml E[D|X]: pystacked $D $X, type(reg) method(svm) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(svm) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster ID)     



********************************************
*Table S5
********************************************
use "C:\Users\10458\Desktop\data\individual.dta", clear
winsor2 rif_ci_pca,cuts(1 99)
winsor2 age, cuts(1 99)
winsor2 age_2, cuts(1 99)
winsor2 log_per_gdp ,cuts(1 99)
winsor2 log_per_gdp_2 ,cuts(1 99)
winsor2 per_bed ,cuts(1 99)
winsor2 per_bed_2 ,cuts(1 99)
winsor2 per_doc ,cuts(1 99)
winsor2 per_doc_2 ,cuts(1 99)
global Y rif_ci_pca_w
global X age_w i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp_w per_bed_w per_doc_w  age_2_w log_per_gdp_2_w per_bed_2_w per_doc_2_w i.city_code i.year 
global D Broad_band_China1
set seed 42    
local py_seed 42    
ddml init partial, kfolds(4)
ddml E[D|X]: pystacked $D $X, type(reg) method(svm) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(svm) pyseed(`py_seed') 
ddml crossfit
ddml estimate,vce(cluster ID)  

use "C:\Users\10458\Desktop\data\individual.dta", clear
drop if city=="北京市"
drop if city=="天津市"
drop if city=="上海市"
drop if city=="重庆市"
global Y rif_ci_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc age_2  log_per_gdp_2 per_bed_2 per_doc_2 i.city_code i.year 
global D Broad_band_China1
set seed 42    
local py_seed 42  
ddml init partial, kfolds(4)
ddml E[D|X]: pystacked $D $X, type(reg) method(svm) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(svm) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster ID)  

use "C:\Users\10458\Desktop\data\individual.dta", clear
g iv = post_tele_ser*year
global Y rif_ci_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc age_2  log_per_gdp_2 per_bed_2 per_doc_2 i.city_code i.year 
global D Broad_band_China1
global Z iv
set seed 42  
ddml init iv, kfolds(4)  
ddml E[Y|X]: pystacked $Y $X, type(reg) method(svm)
ddml E[D|X]: pystacked $D $X, type(reg) method(svm)
ddml E[Z|X]: pystacked $Z $X, type(reg) method(svm)
ddml crossfit
ddml estimate, vce(cluster ID)    

use "C:\Users\10458\Desktop\data\individual.dta", clear
global Y rif_wi_pca
global X age i.gender i.rural i.marry i.edu i.smoken i.drinkl log_per_gdp per_bed per_doc  age_2 log_per_gdp_2 per_bed_2 per_doc_2 i.city_code i.year
global D Broad_band_China1
set seed 42
local py_seed 42
ddml init partial, kfolds(4)
ddml E[D|X]: pystacked $D $X, type(reg) method(svm) pyseed(`py_seed') 
ddml E[Y|X]: pystacked $Y $X, type(reg) method(svm) pyseed(`py_seed') 
ddml crossfit
ddml estimate, vce(cluster ID)    

