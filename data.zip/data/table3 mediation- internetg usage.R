
library(haven)
individual <- read_dta("individual.dta")
View(individual)


library(tidyr)
individual <- individual %>% drop_na(social10)



y <- individual$health_pca
d <- individual$Broad_band_China1
m <- individual$social10_new
x <- cbind(
  age           = individual$age,
  imarry        = factor(individual$marry),
  idrinkl       = factor(individual$drinkl),
  ismoken       = factor(individual$smoken),
  igender       = factor(individual$gender),
  irural        = factor(individual$rural),
  iedu          = factor(individual$edu),
  log_per_gdp   = individual$log_per_gdp,
  per_bed       = individual$per_bed,
  per_doc       = individual$per_doc,
  age_2         = individual$age_2,
  log_per_gdp_2 = individual$log_per_gdp_2,
  per_bed_2     = individual$per_bed_2,
  per_doc_2     = individual$per_doc_2,
  iyear         = factor(individual$year),
  icity_code    = factor(individual$city_code)
)

library(causalweight)
set.seed(42)

cat("y length:", length(y), "\n")
cat("d length:", length(d), "\n")
cat("m length:", length(m), "\n")
cat("x dimensions:", dim(x), "\n")

medDML(
  y,
  d,
  m,
  x,
  k = 4,
  trim = 0.05,
  order = 1,
  multmed = TRUE,
  fewsplits = FALSE,
  normalized = TRUE,
  MLmethod = "lasso"
)
